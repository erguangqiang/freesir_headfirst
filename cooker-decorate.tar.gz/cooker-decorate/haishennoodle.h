#ifndef __HAISHENNOODLE__H__
#define __HAISHENNOODLE__H__

#include "food.h"
class haishennoodle : public food
{
public:
	haishennoodle();
	~haishennoodle();

	double get_price();
	char *get_food_name();
};

#endif//__HAISHENNOODLE__H__