#ifndef __DECORATE__H__
#define __DECORATE__H__

#include "food.h"

class decorate : public food
{
protected:
	decorate() {};
	~decorate() {};

protected:
	food  *m_dec;
};

#endif//__DECORATE__H__