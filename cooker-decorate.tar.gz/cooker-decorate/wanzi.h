#ifndef __WANZI__H__
#define __WANZI__H__

#include "decorate.h"

class wanzi : public decorate
{
public:
	wanzi(food *d);
	~wanzi();

	double get_price();
	char * get_food_name() { return m_food; }
};

#endif//__WANZI__H__