#ifndef __FOOD__H__
#define __FOOD__H__

class food
{
protected:
	food() {}
	~food() {};

public:
	virtual double get_price() = 0;
	virtual char *get_food_name() = 0;

protected:
	char *m_food;
	double m_price;
};

#endif//__FOOD__H__