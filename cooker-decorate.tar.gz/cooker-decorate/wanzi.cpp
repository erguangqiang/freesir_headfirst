#include <iostream>
#include "wanzi.h"

wanzi::wanzi(food *d)
{
	m_food = "丸子";
	m_price = 1.80;
	m_dec = d;
}

wanzi::~wanzi()
{

}

double wanzi::get_price()
{
	if(m_dec) {
		std::cout << "丸子    1份    1.80元/份" << std::endl;
		return m_dec->get_price() + m_price;
	}
	return m_price;
}