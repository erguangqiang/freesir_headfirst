#include <iostream>
#include "haishennoodle.h"

haishennoodle::haishennoodle()
{
	m_food = "海参炒面";
	m_price = 18.00;
}

haishennoodle::~haishennoodle()
{
}

double haishennoodle::get_price()
{
	std::cout << "海参炒面     1份     18.00元/份" << std::endl;
	return m_price;
}

char *haishennoodle::get_food_name()
{
	return m_food;
}