#ifndef __HAIDAI__H__
#define __HAIDAI__H__

#include "decorate.h"

class haidai : public decorate
{
public:
	haidai(food *d);
	~haidai();

	double get_price();
	char * get_food_name() { return m_food; }
};

#endif//__HAIDAI__H__