#include <iostream>
#include "ludan.h"

ludan::ludan(food *d)
{
	m_food = "卤蛋";
	m_price = 1.50;
	m_dec = d;
}

ludan::~ludan()
{

}

double ludan::get_price()
{
	if(m_dec) {
		std::cout << "卤蛋    1份    1.50元/份" << std::endl;
		return m_dec->get_price() + m_price;
	}
	return m_price;
}