#ifndef __LAGENNOODLE__H__
#define __LAGENNOODLE__H__

#include "food.h"

class lagennoodle : public food
{
public:
	lagennoodle();
	~lagennoodle();

	double get_price();
	char *get_food_name();
};

#endif//__LAGENNOODLE__H__