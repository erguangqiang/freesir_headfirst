#include <iostream>
#include "haidai.h"

haidai::haidai(food *d)
{
	m_food = "海带";
	m_price = 2.00;
	m_dec = d;
}

haidai::~haidai()
{

}

double haidai::get_price()
{
	if(m_dec) {
		std::cout << "海带    1份    2.00元/份" << std::endl;
		return m_dec->get_price() + m_price;
	}
	return m_price;
}