#ifndef __LUDAN__H__
#define __LUDAN__H__

#include "decorate.h"

class ludan : public decorate
{
public:
	ludan(food *d);
	~ludan();

	double get_price();
	char * get_food_name() { return m_food; }
};

#endif//__LUDAN__H__