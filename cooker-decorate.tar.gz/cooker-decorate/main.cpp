#include <iostream>

#include "haishennoodle.h"
#include "lagennoodle.h"

#include "wanzi.h"
#include "haidai.h"
#include "ludan.h"

using namespace std;

int main(int argc, char **argv)
{
	food *f = NULL;

	cout << "老板，来一份海参炒面！！" << endl;
	f = new haishennoodle();

	cout << "老板，海参炒面里面加一个卤蛋和海带！！" << endl;
	decorate *hd = new haidai(f);
	decorate *ld = new ludan(hd);
	
	//开始给装饰海参炒面
	cout << "您的面钱一共是 ：" << endl;
	cout << ld->get_price() << endl;
	delete (haishennoodle *)f; f = NULL;
	delete (ludan *)ld; ld = NULL;
	delete (haidai *)hd; hd = NULL;

	cout << "--------------------------------------------" << endl;
	cout << "老板，来一份辣根汤面，加两个卤蛋和一个丸子！！！" << endl;
	f = new lagennoodle();
	decorate *ld1 = new ludan(f);
	decorate *ld2 = new ludan(ld1);
	decorate *wz = new wanzi(ld2);

	//开始装饰辣根汤面
	cout << "您的面钱一共是 ： " << endl;
	cout << wz->get_price() << endl;
	cout << "--------------------------------------------" << endl;
	
	return 0;
}