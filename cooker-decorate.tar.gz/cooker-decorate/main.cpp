#include <iostream>

#include "haishennoodle.h"
#include "lagennoodle.h"

#include "wanzi.h"
#include "haidai.h"
#include "ludan.h"

using namespace std;

int main(int argc, char **argv)
{
	food *f = NULL;

	cout << "老板，来一份海参炒面！！" << endl;
	f = new haishennoodle();

	cout << "老板，海参炒面里面加一个卤蛋和海带！！" << endl;
	decorate *hd = new haidai(f);
	decorate *ld = new ludan(hd);
	
	//开始给装饰海参炒面
	cout << "您的面钱一共是 ：" << endl;
	cout << ld->get_price() << endl;
	delete (haishennoodle *)f; f = NULL;
	delete (ludan *)ld; ld = NULL;
	delete (haidai *)hd; hd = NULL;

	cout << "--------------------------------------------" << endl;
	cout << "老板，来一份辣根汤面，加两个卤蛋和一个丸子！！！" << endl;
	f = new lagennoodle();
	decorate *ld1 = new ludan(f);
	decorate *ld2 = new ludan(ld1);
	decorate *wz = new wanzi(ld2);

	//开始装饰辣根汤面
	cout << "您的面钱一共是 ： " << endl;
	cout << wz->get_price() << endl;
	delete (lagennoodle *)f; f = NULL;
	delete (ludan *)ld1; ld1 = NULL;
	delete (ludan *)ld2; ld2 = NULL;
	delete (wanzi *)wz; wz = NULL;

	cout << "--------------------------------------------" << endl;
	cout << "老板，不要面，来3个卤蛋，两个海带，5个丸子！！！" << endl;
	decorate *ld3 = new ludan(NULL);
	decorate *ld4 = new ludan(ld3);
	decorate *ld5 = new ludan(ld4);

	decorate *hd1 = new haidai(ld5);
	decorate *hd2 = new haidai(hd1);

	decorate *wz1 = new wanzi(hd2);
	decorate *wz2 = new wanzi(wz1);
	decorate *wz3 = new wanzi(wz2);
	decorate *wz4 = new wanzi(wz3);
	decorate *wz5 = new wanzi(wz4);

	cout << "您的面钱一共是 ： " << endl;
	cout << wz5->get_price() << endl;
	delete (ludan *)ld3; ld3 = NULL;
	delete (ludan *)ld4; ld4 = NULL;
	delete (ludan *)ld5; ld5 = NULL;
	delete (haidai *)hd1; hd1 = NULL;
	delete (haidai *)hd2; hd2 = NULL;
	delete (wanzi *)wz1; wz1 = NULL;
	delete (wanzi *)wz2; wz2 = NULL;
	delete (wanzi *)wz3; wz3 = NULL;
	delete (wanzi *)wz4; wz4 = NULL;
	delete (wanzi *)wz5; wz5 = NULL;
	cout << "--------------------------------------------" << endl;

	return 0;
}