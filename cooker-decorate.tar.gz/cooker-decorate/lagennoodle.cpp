#include <iostream>
#include "lagennoodle.h"

lagennoodle::lagennoodle()
{
	m_food = "辣根汤面";
	m_price = 12.00;
}

lagennoodle::~lagennoodle()
{
	
}

double lagennoodle::get_price()
{
	std::cout << "辣根汤面     1份     12.00元/份" << std::endl;
	return m_price;
}

char *lagennoodle::get_food_name()
{
	return m_food;
}