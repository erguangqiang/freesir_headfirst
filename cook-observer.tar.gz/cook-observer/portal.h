#ifndef PORTAL_H
#define PORTAL_H
#include <list>
#include <string>

class qishou;

typedef std::list<qishou *>  qslist;
class portal
{
public:
    portal() {}
    virtual ~portal() {}

    virtual int attach(qishou *q) = 0;
    virtual int detach(qishou *q) = 0;

    virtual int notify() = 0;

    std::string get_address() { return m_address; }
    void set_address(std::string &s) { m_address = s; }

protected:
    qslist   m_list;
    std::string  m_address;
};

#endif // PORTAL_H
