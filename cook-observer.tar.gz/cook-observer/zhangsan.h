#ifndef ZHANGSAN_H
#define ZHANGSAN_H

#include "qishou.h"

class portal;
class zhangsan : public qishou
{
public:
    zhangsan(portal *p);
    ~zhangsan();

    int new_order();
};

#endif // ZHANGSAN_H
