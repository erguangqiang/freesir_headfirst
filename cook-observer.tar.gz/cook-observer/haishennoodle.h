#ifndef HAISHENNOODLE_H
#define HAISHENNOODLE_H

#include "portal.h"

class qishou;
class haishennoodle : public portal
{
public:
    haishennoodle();
    ~haishennoodle();

    virtual int attach(qishou *q);
    virtual int detach(qishou *q);

    virtual int notify();
};

#endif // HAISHENNOODLE_H
