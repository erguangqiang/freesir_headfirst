#ifndef LISI_H
#define LISI_H

#include "qishou.h"

class portal;
class lisi : public qishou
{
public:
    lisi(portal *p);
    ~lisi();

    int new_order();
};

#endif // LISI_H
