#ifndef QISHOU_H
#define QISHOU_H

class portal;
class qishou
{
public:
    qishou() {}
    virtual ~qishou() {}

    virtual int new_order() = 0;

protected:
    portal  *m_portal;
};

#endif // QISHOU_H
