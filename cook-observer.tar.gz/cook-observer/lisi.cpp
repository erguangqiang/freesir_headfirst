#include <iostream>

#include "portal.h"
#include "lisi.h"

lisi::lisi(portal *p)
{
    m_portal = p;
}

lisi::~lisi()
{

}

int lisi::new_order()
{
    std::cout << "lisi has one new order. adress is " << m_portal->get_address() << std::endl;
}
