#include <iostream>
#include "haishennoodle.h"
#include "zhangsan.h"
#include "lisi.h"

using namespace std;

int main()
{
    haishennoodle *hsn = new haishennoodle();
    qishou *q1 = new zhangsan(hsn);
    qishou *q2 = new lisi(hsn);

    hsn->attach(q1);
    hsn->attach(q2);

    cout << "has new order!!!" << endl;
    string add1 = "shuianhuayuan 12#904";
    hsn->set_address(add1);
    hsn->notify();

    hsn->detach(q2);
    string add2 = "shuianhuayuan 12#903";
    hsn->set_address(add2);
    cout << "has new order !!!"<< endl;
    hsn->notify();

    delete hsn;
    hsn = NULL;
    return 0;
}
