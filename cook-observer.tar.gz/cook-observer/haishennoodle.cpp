#include "haishennoodle.h"
#include "qishou.h"

haishennoodle::haishennoodle()
{
    m_address = "";
}

haishennoodle::~haishennoodle()
{
    qslist::iterator it = m_list.begin();
    for(; it != m_list.end(); it++) {
        if(*it) {
            delete *it;
        }
    }

    m_list.clear();
}

int haishennoodle::attach(qishou *q)
{
    qslist::iterator it = m_list.begin();
    for(; it != m_list.end(); it++) {
        if(q == *it) {
            return 0;
        }
    }

    m_list.push_back(q);
    return 0;
}

int haishennoodle::detach(qishou *q)
{
    qslist::iterator it = m_list.begin();
    for(; it != m_list.end(); it++) {
        if(q == *it) {
            delete q; q = NULL;
            it = m_list.erase(it);
        }
    }

    return 0;
}

int haishennoodle::notify()
{
    qslist::iterator it = m_list.begin();
    for(; it != m_list.end(); it++) {
        (*it)->new_order();
    }
    return 0;
}
