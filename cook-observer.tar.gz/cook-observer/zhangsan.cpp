#include <iostream>

#include "zhangsan.h"
#include "portal.h"

zhangsan::zhangsan(portal *p)
{
    m_portal = p;
}

zhangsan::~zhangsan()
{

}

int zhangsan::new_order()
{
    std::cout << "zhangsan has one new order. adress is " << m_portal->get_address() << std::endl;
}
