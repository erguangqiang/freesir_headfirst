#include <iostream>
#include "haishenshop.h"

using namespace std;

int main()
{
    haishenshop *hs = new haishenshop();

    cout << "我在美团点了一份海参炒面！！！" << endl;
    hs->create_haishennoodle();

    cout << "我在美团点了一份辣根汤面！！！" << endl;
    hs->create_lagennoodle();
    return 0;
}
