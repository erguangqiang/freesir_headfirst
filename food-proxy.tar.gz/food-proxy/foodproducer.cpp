#include "foodproducer.h"

foodproducer::foodproducer()
{

}
