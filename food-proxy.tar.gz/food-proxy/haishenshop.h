#ifndef HAISHENSHOP_H
#define HAISHENSHOP_H

#include "foodproducer.h"

class foodfactory;
class haishenshop : public foodproducer
{
public:
    haishenshop();
    ~haishenshop();

    virtual void create_haishennoodle();
    virtual void create_lagennoodle();

private:
    foodfactory  *m_fac;
};

#endif // HAISHENSHOP_H
