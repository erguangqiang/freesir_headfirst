#include <iostream>
#include "foodfactory.h"

foodfactory::foodfactory()
{

}

foodfactory::~foodfactory()
{

}

void foodfactory::create_haishennoodle()
{
    std::cout << "我工厂出货一份5元海参炒面！！！" << std::endl;
}

void foodfactory::create_lagennoodle()
{
    std::cout << "我工厂出货一份3元辣根汤面！！！" << std::endl;
}
