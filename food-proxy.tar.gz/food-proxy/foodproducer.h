#ifndef FOODPRODUCER_H
#define FOODPRODUCER_H


class foodproducer
{
public:
    foodproducer() {}
    ~foodproducer() {}

    virtual void create_haishennoodle() = 0;
    virtual void create_lagennoodle() = 0;
};

#endif // FOODPRODUCER_H
