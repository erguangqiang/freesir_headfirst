#ifndef FOODFACTORY_H
#define FOODFACTORY_H

#include "foodproducer.h"

class foodfactory : public foodproducer
{
public:
    foodfactory();
    ~foodfactory();

    virtual void create_haishennoodle();
    virtual void create_lagennoodle();
};

#endif // FOODFACTORY_H
