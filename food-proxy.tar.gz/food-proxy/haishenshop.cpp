#include <iostream>
#include "haishenshop.h"
#include "foodfactory.h"

haishenshop::haishenshop()
{
    m_fac = new foodfactory();
}

haishenshop::~haishenshop()
{
    delete m_fac;
    m_fac = NULL;
}

void haishenshop::create_haishennoodle()
{
    std::cout << "卖出18.00元海参炒面,我是从工厂进的货！！" << std::endl;
    m_fac->create_haishennoodle();
}

void haishenshop::create_lagennoodle()
{
    std::cout << "卖出12元辣根汤面,我是从工厂进的货！！" << std::endl;
    m_fac->create_lagennoodle();
}
