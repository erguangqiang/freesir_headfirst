#include <iostream>
#include "mrwang.h"
#include "mrzhang.h"
#include "noodle.h"

using namespace std;

int main()
{
    cooker *c = new mrzhang();
    //cooker *c = new mrwang();

    lagennoodle *lgn = c->cook_lagennoodle();
    lgn->make_noodle();

    haishennoodle *hsn = c->cook_haishennoodle();
    hsn->make_noodle();

    delete c;
    delete lgn;
    delete hsn;
    return 0;
}
