#include <iostream>
#include "mznoodle.h"

mzlgnoodle::mzlgnoodle()
{

}

mzlgnoodle::~mzlgnoodle()
{

}

int mzlgnoodle::make_noodle()
{
    std::cout << "张师傅制作辣根汤面" << std::endl;
    return 0;
}

mzhsnoodle::mzhsnoodle()
{

}

mzhsnoodle::~mzhsnoodle()
{

}

int mzhsnoodle::make_noodle()
{
    std::cout << "张师傅制作海参炒面" << std::endl;
    return 0;
}
