#include "mrwang.h"
#include "mwnoodle.h"

mrwang::mrwang()
{

}

mrwang::~mrwang()
{

}

lagennoodle *mrwang::cook_lagennoodle()
{
    return new mwlgnoodle();
}

haishennoodle *mrwang::cook_haishennoodle()
{
    return new mwhsnoodle();
}
