#ifndef MWNOODLE_H
#define MWNOODLE_H

#include "noodle.h"

class mwlgnoodle : public lagennoodle
{
public:
    mwlgnoodle();
    virtual ~mwlgnoodle();

    virtual int make_noodle();
};

class mwhsnoodle : public haishennoodle
{
public:
    mwhsnoodle();
    virtual ~mwhsnoodle();

    virtual int make_noodle();
};

#endif // MWNOODLE_H
