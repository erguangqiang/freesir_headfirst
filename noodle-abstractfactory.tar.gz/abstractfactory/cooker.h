#ifndef COOKER_H
#define COOKER_H

class lagennoodle;
class haishennoodle;
class cooker
{
public:
    cooker() {}
    virtual ~cooker() {}

    virtual lagennoodle* cook_lagennoodle() = 0;
    virtual haishennoodle* cook_haishennoodle() = 0;
};

#endif // COOKER_H
