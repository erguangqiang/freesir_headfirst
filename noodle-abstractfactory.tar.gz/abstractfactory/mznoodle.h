#ifndef MZNOODLE_H
#define MZNOODLE_H

#include "noodle.h"

class mzlgnoodle : public lagennoodle
{
public:
    mzlgnoodle();
    virtual ~mzlgnoodle();

    virtual int make_noodle();
};

class mzhsnoodle : public haishennoodle
{
public:
    mzhsnoodle();
    virtual ~mzhsnoodle();

    virtual int make_noodle();
};

#endif // MZNOODLE_H
