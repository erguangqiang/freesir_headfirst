#ifndef MRZHANG_H
#define MRZHANG_H

#include "cooker.h"

class mrzhang : public cooker
{
public:
    mrzhang();
    virtual ~mrzhang();

    virtual lagennoodle* cook_lagennoodle();
    virtual haishennoodle* cook_haishennoodle();
};

#endif // MRZHANG_H
