#include <iostream>
#include "mwnoodle.h"

mwlgnoodle::mwlgnoodle()
{

}

mwlgnoodle::~mwlgnoodle()
{

}

int mwlgnoodle::make_noodle()
{
    std::cout << "王师傅制作辣根汤面" << std::endl;
    return 0;
}

mwhsnoodle::mwhsnoodle()
{

}

mwhsnoodle::~mwhsnoodle()
{

}

int mwhsnoodle::make_noodle()
{
    std::cout << "王师傅制作海参炒面" << std::endl;
    return 0;
}
