#ifndef NOODLE_H
#define NOODLE_H

class lagennoodle
{
public:
    lagennoodle() {}
    virtual ~lagennoodle() {}

    virtual int make_noodle() = 0;
};

class haishennoodle
{
public:
    haishennoodle() {}
    virtual ~haishennoodle() {}

    virtual int make_noodle() = 0;
};

#endif // NOODLE_H
