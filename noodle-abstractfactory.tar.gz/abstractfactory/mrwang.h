#ifndef MRWANG_H
#define MRWANG_H

#include "cooker.h"

class mrwang : public cooker
{
public:
    mrwang();
    virtual ~mrwang();

    virtual lagennoodle *cook_lagennoodle();
    virtual haishennoodle *cook_haishennoodle();
};

#endif // MRWANG_H
