#include "mrzhang.h"
#include "mznoodle.h"

mrzhang::mrzhang()
{

}

mrzhang::~mrzhang()
{

}


lagennoodle *mrzhang::cook_lagennoodle()
{
    return new mzlgnoodle();
}

haishennoodle *mrzhang::cook_haishennoodle()
{
    return new mzhsnoodle();
}
