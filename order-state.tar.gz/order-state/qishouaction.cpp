#include <iostream>

#include "qishouaction.h"
#include "postqishouaction.h"
#include "orderstate.h"

qishouaction::qishouaction()
{

}

qishouaction::~qishouaction()
{

}

int qishouaction::doaction(orderstate *o)
{
    if(o->get_state() == S_QISHOU) {
        std::cout << "骑手开始取餐啦！！！" << std::endl;
    } else {
        o->set_action(new postqishouaction());
        o->request();
    }
}
