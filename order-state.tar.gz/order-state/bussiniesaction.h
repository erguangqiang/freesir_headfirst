#ifndef BUSSINIESACTION_H
#define BUSSINIESACTION_H

#include "action.h"

class orderstate;
class bussiniesaction : public action
{
public:
    bussiniesaction();
    ~bussiniesaction();

    virtual int doaction(orderstate *o);
};

#endif // BUSSINIESACTION_H
