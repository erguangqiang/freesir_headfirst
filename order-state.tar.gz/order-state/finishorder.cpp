#include <iostream>
#include "finishorder.h"
#include "orderstate.h"
#include "payorderaction.h"

finishorder::finishorder()
{

}

finishorder::~finishorder()
{

}

int finishorder::doaction(orderstate *o)
{
    if(o->get_state() == S_FINISH) {
        std::cout << "完成订单啦！！！" << std::endl;
    } else {
        o->set_action(new payorderaction());
        o->request();
    }
}
