#ifndef PAYORDERACTION_H
#define PAYORDERACTION_H

#include "action.h"

class orderstate;
class payorderaction : public action
{
public:
    payorderaction();
    ~payorderaction();

    virtual int doaction(orderstate *o);
};

#endif // PAYORDERACTION_H
