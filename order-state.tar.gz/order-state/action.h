#ifndef ACTION_H
#define ACTION_H

class orderstate;
class action
{
public:
    action() {}
    virtual ~action() {}

public:
    virtual int doaction(orderstate *o) = 0;
};

#endif // ACTION_H
