#include <iostream>

#include "payorderaction.h"
#include "bussiniesaction.h"
#include "orderstate.h"

payorderaction::payorderaction()
{

}

payorderaction::~payorderaction()
{

}

int payorderaction::doaction(orderstate *o)
{
    if(o->get_state() == S_PAYORDER) {
        std::cout << "客人准备支付订单啦！！！" << std::endl;
    } else {
        o->set_action(new bussiniesaction());
        o->request();
    }
}
