#include <iostream>
#include "orderstate.h"

using namespace std;

int main()
{
    orderstate *os = new orderstate();
    cout << "美团点餐一份海参炒面，目前订单状态如下：" << endl;
    os->set_state(S_PAYORDER);
    os->request();

    os->set_state(S_BUSSINIES);
    os->request();

    os->set_state(S_QISHOU);
    os->request();

    os->set_state(S_POSTQISHOU);
    os->request();

    os->set_state(S_FINISH);
    os->request();

    return 0;
}
