#ifndef FINISHORDER_H
#define FINISHORDER_H

#include "action.h"

class orderstate;
class finishorder : public action
{
public:
    finishorder();
    ~finishorder();

    virtual int doaction(orderstate *o);
};

#endif // FINISHORDER_H
