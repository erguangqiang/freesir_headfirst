#include <iostream>
#include "postqishouaction.h"
#include "finishorder.h"
#include "orderstate.h"

postqishouaction::postqishouaction()
{

}

postqishouaction::~postqishouaction()
{

}

int postqishouaction::doaction(orderstate *o)
{
    if(o->get_state() == S_POSTQISHOU) {
        std::cout << "骑手开始送餐啦！！！" << std::endl;
    } else {
        o->set_action(new finishorder());
        o->request();
    }
}
