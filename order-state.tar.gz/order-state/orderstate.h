#ifndef ORDERSTATE_H
#define ORDERSTATE_H

#include "action.h"

typedef enum {
    S_PAYORDER = 0,
    S_BUSSINIES = 1,
    S_QISHOU = 2,
    S_POSTQISHOU = 3,
    S_FINISH = 4,
}order_state;

class orderstate
{
public:
    orderstate();
    ~orderstate();

    int get_state() { return m_state; }
    void set_state(int s) { m_state = s; }

    void set_action(action *a) { if(m_action) delete m_action; m_action = a; }

    int request();

private:
    int   m_state;
    action *m_action;
};

#endif // ORDERSTATE_H
