#include <iostream>

#include "bussiniesaction.h"
#include "qishouaction.h"
#include "orderstate.h"

bussiniesaction::bussiniesaction()
{

}

bussiniesaction::~bussiniesaction()
{

}

int bussiniesaction::doaction(orderstate *o)
{
    if(o->get_state() == S_BUSSINIES) {
        std::cout << "商家开始接单啦！！！" << std::endl;
    } else {
        o->set_action(new qishouaction());
        o->request();
    }
}
