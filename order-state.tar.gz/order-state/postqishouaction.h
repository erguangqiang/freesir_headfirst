#ifndef POSTQISHOUACTION_H
#define POSTQISHOUACTION_H

#include "action.h"

class orderstate;
class postqishouaction : public action
{
public:
    postqishouaction();
    ~postqishouaction();

    virtual int doaction(orderstate *o);
};

#endif // POSTQISHOUACTION_H
