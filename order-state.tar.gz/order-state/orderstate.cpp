#include <iostream>
#include "orderstate.h"
#include "action.h"
#include "payorderaction.h"

orderstate::orderstate()
{
    m_action = new payorderaction();
}

orderstate::~orderstate()
{
    if(m_action) {
        delete m_action;
        m_action = NULL;
    }
}

int orderstate::request()
{
    m_action->doaction(this);
}
