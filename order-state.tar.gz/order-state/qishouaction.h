#ifndef QISHOUACTION_H
#define QISHOUACTION_H

#include "action.h"

class orderstate;
class qishouaction : public action
{
public:
    qishouaction();
    ~qishouaction();

    virtual int doaction(orderstate *o);
};

#endif // QISHOUACTION_H
