#ifndef HAISHENNOODLE_H
#define HAISHENNOODLE_H

#include "noodle.h"

class haishennoodle : public noodle
{
public:
    haishennoodle();
    virtual ~haishennoodle();

    haishennoodle *get_noodle();
};

#endif // HAISHENNOODLE_H
