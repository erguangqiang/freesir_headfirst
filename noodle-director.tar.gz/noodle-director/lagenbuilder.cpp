#include <iostream>
#include "lagenbuilder.h"

lagenbuilder::lagenbuilder()
{

}

lagenbuilder::~lagenbuilder()
{

}

void lagenbuilder::oilling()
{
    std::cout << "辣根汤面，不放油，只放辣根。" << std::endl;
}

void lagenbuilder::vegetables()
{
    std::cout << "辣根汤面，不放蔬菜，只放辣根。" << std::endl;
}

void lagenbuilder::noodle()
{
    std::cout << "辣根汤面，不放面条，只放辣根。" << std::endl;
}

void lagenbuilder::salting()
{
    std::cout << "辣根汤面，不放盐，只放辣根。" << std::endl;
}
