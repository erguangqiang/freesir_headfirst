#include <iostream>
#include "lagenbuilder.h"

lagenbuilder::lagenbuilder()
{

}

lagenbuilder::~lagenbuilder()
{

}

void lagenbuilder::oilling()
{
    std::cout << "辣根汤面，不放油，只放辣根。" << std::endl;
    m_noo->m_oil = 0;
}

void lagenbuilder::vegetables()
{
    std::cout << "辣根汤面，不放蔬菜，只放辣根。" << std::endl;
    m_noo->m_vegetables = 0;
}

void lagenbuilder::noodles()
{
    std::cout << "辣根汤面，不放面条，只放辣根。" << std::endl;
    m_noo->m_noodle = 0;
}

void lagenbuilder::salting()
{
    std::cout << "辣根汤面，不放盐，只放辣根。" << std::endl;
    m_noo->m_salt = 0;
}
