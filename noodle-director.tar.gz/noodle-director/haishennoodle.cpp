#include "haishennoodle.h"

haishennoodle::haishennoodle()
{

}
