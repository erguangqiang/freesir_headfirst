#ifndef DIRECTOR_H
#define DIRECTOR_H

class builder;
class director
{
public:
    director();
    virtual ~director();

    void construct(builder *b);
};

#endif // DIRECTOR_H
