#ifndef HAISHENBUILDER_H
#define HAISHENBUILDER_H

#include "builder.h"

class haishenbuilder : public builder
{
public:
    haishenbuilder();
    virtual ~haishenbuilder();

    virtual void oilling();
    virtual void vegetables();
    virtual void noodles();
    virtual void salting();
};

#endif // HAISHENBUILDER_H
