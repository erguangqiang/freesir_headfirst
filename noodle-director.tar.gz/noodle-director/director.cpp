#include "director.h"
#include "builder.h"

director::director()
{

}

director::~director()
{

}

void director::construct(builder *b)
{
    b->oilling();
    b->vegetables();
    b->noodles();
    b->salting();
}
