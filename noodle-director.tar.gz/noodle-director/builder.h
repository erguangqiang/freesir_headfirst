#ifndef BUILDER_H
#define BUILDER_H


class builder
{
public:
    builder() {}
    virtual ~builder() {}

    virtual void oilling() = 0;
    virtual void vegetables() = 0;
    virtual void noodle() = 0;
    virtual void salting() = 0;
};

#endif // BUILDER_H
