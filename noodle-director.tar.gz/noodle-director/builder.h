#ifndef BUILDER_H
#define BUILDER_H

#include "noodle.h"

class builder
{
public:
    builder() { m_noo = new noodle(); }
    virtual ~builder() { delete m_noo; m_noo = NULL; }

    virtual void oilling() = 0;
    virtual void vegetables() = 0;
    virtual void noodles() = 0;
    virtual void salting() = 0;

    noodle *get_noodle() { return m_noo; }
protected:
    noodle *m_noo;
};

#endif // BUILDER_H
