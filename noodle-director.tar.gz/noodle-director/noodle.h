#ifndef NOODLE_H
#define NOODLE_H

#include <iostream>

class noodle
{
public:
    noodle() {}
    virtual ~noodle() {}

public:
    int m_oil;
    int m_vegetables;
    int m_noodle;
    int m_salt;
};

#endif // NOODLE_H
