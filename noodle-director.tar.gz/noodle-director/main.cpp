#include <iostream>
#include "director.h"
#include "haishenbuilder.h"
#include "lagenbuilder.h"

using namespace std;

int main()
{
    haishenbuilder *hsb = new haishenbuilder();
    director *d = new director();

    d->construct(hsb);

    lagenbuilder *lgb = new lagenbuilder();
    d->construct(lgb);
    return 0;
}
