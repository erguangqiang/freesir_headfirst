#include <iostream>
#include "director.h"
#include "haishenbuilder.h"
#include "lagenbuilder.h"

using namespace std;

int main()
{
    haishenbuilder *hsb = new haishenbuilder();
    director *d = new director();

    d->construct(hsb);
    noodle *n = hsb->get_noodle();
    cout << n->m_oil << "----" << n->m_vegetables << "----" << n->m_noodle << "---" << n->m_salt << endl;

    lagenbuilder *lgb = new lagenbuilder();
    d->construct(lgb);
    n = lgb->get_noodle();
    cout << n->m_oil << "----" << n->m_vegetables << "----" << n->m_noodle << "---" << n->m_salt << endl;

    return 0;
}
