#include <iostream>
#include "haishenbuilder.h"

haishenbuilder::haishenbuilder()
{

}

haishenbuilder::~haishenbuilder()
{

}

void haishenbuilder::oilling()
{
    std::cout << "海参炒面，放入25g葵花子食用油。" << std::endl;
    m_noo->m_oil = 25;
}

void haishenbuilder::vegetables()
{
    std::cout << "海参炒面，放入一些油菜和西红柿。" << std::endl;
    m_noo->m_vegetables = 200;
}

void haishenbuilder::noodles()
{
    std::cout << "海参炒面，放入300g面条。" << std::endl;
    m_noo->m_noodle = 300;
}

void haishenbuilder::salting()
{
    std::cout << "海参炒面，放入3g食用盐。" << std::endl;
    m_noo->m_salt = 3;
}
