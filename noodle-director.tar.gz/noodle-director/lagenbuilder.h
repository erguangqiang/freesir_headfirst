#ifndef LAGENBUILDER_H
#define LAGENBUILDER_H

#include "builder.h"

class lagenbuilder : public builder
{
public:
    lagenbuilder();
    virtual ~lagenbuilder();

    virtual void oilling();
    virtual void vegetables();
    virtual void noodles();
    virtual void salting();
};

#endif // LAGENBUILDER_H
