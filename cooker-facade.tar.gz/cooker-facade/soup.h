#ifndef SOUP_H
#define SOUP_H


class soup
{
public:
    soup();
    ~soup();

public:
    void makesoup();
};

#endif // SOUP_H
