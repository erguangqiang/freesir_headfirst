#include <iostream>
#include "soup.h"

soup::soup()
{

}

soup::~soup()
{

}

void soup::makesoup()
{
    std::cout << "开始做汤底啦！！！" << std::endl;
}
