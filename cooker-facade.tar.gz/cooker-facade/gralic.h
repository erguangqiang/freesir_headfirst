#ifndef GRALIC_H
#define GRALIC_H

class gralic
{
public:
    gralic();
    ~gralic();

public:
    void peelinggralic();
};

#endif // GRALIC_H
