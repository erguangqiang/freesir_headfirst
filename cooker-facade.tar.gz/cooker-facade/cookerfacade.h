#ifndef COOKERFACADE_H
#define COOKERFACADE_H

class gralic;
class noodle;
class soup;
class lagen;
class cookerfacade
{
public:
    cookerfacade();
    ~cookerfacade();

public:
    void makehaishennoodle();
    void makelagennoodle();

private:
    gralic *m_gra;
    noodle *m_noo;
    soup   *m_so;
    lagen  *m_lg;
};

#endif // COOKERFACADE_H
