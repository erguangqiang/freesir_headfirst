#include <iostream>

#include "gralic.h"

gralic::gralic()
{

}

gralic::~gralic()
{

}

void gralic::peelinggralic()
{
    std::cout << "开始剥蒜啦！！！" << std::endl;
}
