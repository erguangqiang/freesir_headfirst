#include <iostream>
#include "cookerfacade.h"

using namespace std;

int main()
{
    cookerfacade *cf = new cookerfacade();

    cout << "老板，来一份辣根汤面！！！" << endl;
    cf->makelagennoodle();

    cout << "老板，换一份海参炒面！！！" << endl;
    cf->makehaishennoodle();
    return 0;
}
