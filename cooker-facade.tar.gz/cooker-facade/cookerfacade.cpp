#include <iostream>
#include "cookerfacade.h"
#include "gralic.h"
#include "noodle.h"
#include "soup.h"
#include "lagen.h"

cookerfacade::cookerfacade()
{
    m_gra = new gralic();
    m_noo = new noodle();
    m_so = new soup();
    m_lg = new lagen();
}

cookerfacade::~cookerfacade()
{
    delete m_gra; m_gra = NULL;
    delete m_noo; m_noo = NULL;
    delete m_so; m_so = NULL;
    delete m_lg; m_lg = NULL;
}

void cookerfacade::makehaishennoodle()
{
    m_gra->peelinggralic();
    m_noo->makenoodle();
    m_so->makesoup();

    std::cout << "开始做海参炒面啦！！！" << std::endl;
}

void cookerfacade::makelagennoodle()
{
    m_lg->makelagen();

    std::cout << "开始作辣根汤面啦！！！" << std::endl;
}
