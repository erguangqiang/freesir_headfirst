#include <iostream>
#include "lagen.h"

lagen::lagen()
{

}

lagen::~lagen()
{

}

void lagen::makelagen()
{
    std::cout << "开始制作辣根！！！" << std::endl;
}
