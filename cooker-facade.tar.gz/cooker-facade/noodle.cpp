#include <iostream>
#include "noodle.h"

noodle::noodle()
{

}

noodle::~noodle()
{

}

void noodle::makenoodle()
{
    std::cout << "开始拉面啦！！！" << std::endl;
}
