#ifndef LAGEN_H
#define LAGEN_H


class lagen
{
public:
    lagen();
    ~lagen();

public:
    void makelagen();
};

#endif // LAGEN_H
