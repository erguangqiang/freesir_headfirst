#ifndef NOODLE_H
#define NOODLE_H


class noodle
{
public:
    noodle();
    ~noodle();

public:
    void makenoodle();
};

#endif // NOODLE_H
