#include <iostream>
#include "context.h"

#include "cooker.h"

context::context(cooker * c)
{
    m_cooker = c;
}

context::~context()
{
}

void context::cooking()
{
    if(m_cooker) {
        std::cout << "放油：";
        m_cooker->take_oil();

        std::cout << "放蔬菜：";
        m_cooker->take_vegetable();

        std::cout << "放面条：";
        m_cooker->take_noodle();

        std::cout << "放盐：";
        m_cooker->take_salt();
    }
}