#ifndef __CONTEXT__H__
#define __CONTEXT__H__

class cooker;
class context
{
public:
    context(cooker *c);
    ~context();

public:
    virtual void cooking();

private:
    cooker *m_cooker;
};

#endif//__CONTEXT__H__
