#ifndef __CONTEXT__H__
#define __CONTEXT__H__

class cooker;
class context
{
public:
    context();
    ~context();

public:
	virtual void set_cooker(cooker *c);
    virtual void cooking();

private:
    cooker *m_cooker;
};

#endif//__CONTEXT__H__
