#ifndef __COOKER__H__
#define __COOKER__H__

class cooker 
{
public:
    cooker() {}
    ~cooker() {}

public:
    virtual void take_oil() = 0;
    virtual void take_vegetable() = 0;
    virtual void take_noodle() = 0;
    virtual void take_salt() = 0;
};

#endif//__COOKER__H__