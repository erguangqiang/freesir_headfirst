#ifndef __HAISHEN__H__
#define __HAISHEN__H__

#include "cooker.h"

class haishen : public cooker
{
public:
    haishen();
    ~haishen();

public:
    virtual void take_oil();
    virtual void take_vegetable();
    virtual void take_noodle();
    virtual void take_salt();
};

#endif//__HAISHEN__H__
