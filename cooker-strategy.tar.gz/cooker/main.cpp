#include <iostream>
#include <string.h>

#include "context.h"
#include "lagen.h"
#include "haishen.h"

using namespace std;

char *product_list[] = {
    "haishen-noodle",
    "lagen-noodle",
    NULL
};

int main()
{
    char *p = NULL;
    char *pd = "lagen-noodle";
    int i = 0;

    context *c = NULL;
    cooker *cooker = NULL;

    for(p = product_list[i]; p != NULL; i++, p = product_list[i]) {
        if(strncmp(pd, p, strlen(pd)) == 0) {
            if(i == 0) {
                cooker = new haishen();
                c = new context(cooker);

                if(c) c->cooking();
            }
            
            if(i == 1) {
                cooker = new lagen();
                c = new context(cooker);

                if(c) c->cooking();
            }
        }
    }

    if(cooker) {
        delete cooker; cooker = NULL;
    }

    if(c) {
        delete c; c = NULL;
    }

    return 0;
}

