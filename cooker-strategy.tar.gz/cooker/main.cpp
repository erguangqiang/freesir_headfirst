#include <iostream>
#include <string.h>

#include "context.h"
#include "lagen.h"
#include "haishen.h"

using namespace std;

int main()
{
    context *c = new context();
    cooker *cooker = NULL;

    cout << "老板，来一份海参炒面！！" << endl;
    //实例化海参炒面算法
    cooker = new haishen();

    if(c) {
        c->set_cooker(cooker);
        c->cooking();
    }
    delete (haishen *)cooker; cooker = NULL;

    cout << "------------------------------" << endl;

    cout << "老板，我要用炒面换汤面！！！" << endl;
    //实例化辣根汤面算法
    cooker = new lagen();

    if(c) {
        c->set_cooker(cooker);
        c->cooking();
    }
    delete (lagen *)cooker; cooker = NULL;

    cout << "-----------------------------" << endl;

    if(c) {
        delete c; c = NULL;
    }

    return 0;
}

