#include <iostream>
#include "haishen.h"

haishen::haishen()
{
}

haishen::~haishen()
{
}

void haishen::take_oil()
{
    std::cout << "海参炒面，起锅烧油！！！" << std::endl;
}

void haishen::take_vegetable()
{
    std::cout << "海参炒面，没有海参，炝锅放蔬菜！！！" << std::endl;
}

void haishen::take_noodle()
{
    std::cout << "海参炒面，没有海参，放点面条对付对付吧！！！" << std::endl;
}

void haishen::take_salt()
{
    std::cout << "海参炒面，没有海参，放点盐出锅！！！" << std::endl;
}