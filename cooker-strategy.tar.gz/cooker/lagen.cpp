#include <iostream>
#include "lagen.h"

lagen::lagen()
{
}

lagen::~lagen()
{
}

void lagen::take_oil()
{
    std::cout << "辣根汤面不放油，只放辣根！！！" << std::endl;
}

void lagen::take_vegetable()
{
    std::cout << "辣根汤面不放蔬菜，只放辣根！！！" << std::endl;
}

void lagen::take_noodle()
{
    std::cout << "辣根汤面不放面条，只放辣根！！！" << std::endl;
}

void lagen::take_salt()
{
    std::cout << "辣根汤面不放盐，只放辣根！！！" << std::endl;
}

