#ifndef __LAGEN__H__
#define __LAGEN__H__

#include "cooker.h"

class lagen : public cooker
{
public:
    lagen();
    ~lagen();

public:
    virtual void take_oil();
    virtual void take_vegetable();
    virtual void take_noodle();
    virtual void take_salt();
};

#endif//__LAGEN__H__
