#include <iostream>
#include "waiter.h"

using namespace std;

int main()
{
    waiter *wa = waiter::instance();
    if(!wa) {
        cout << "this restrant has no waiter." << endl;
        return 0;
    }

    // book haishen noodle
    cout << "服务员来一份海参炒面！！！" << endl;
    wa->bookfood("海参炒面");

    // book lagen noodle
    cout << "服务员来一份辣根汤面！！！" << endl;
    wa->bookfood("辣根汤面");

    waiter::distance();
    return 0;
}
