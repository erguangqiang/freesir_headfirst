#ifndef WAITER_H
#define WAITER_H

#include <iostream>

class waiter
{
protected:
    waiter();
    ~waiter();

public:
    static waiter *instance();
    static void distance();

    void bookfood(const char *food);

private:
    static waiter *m_wa;
};

#endif // WAITER_H
