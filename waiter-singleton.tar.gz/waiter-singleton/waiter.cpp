#include <string>
#include "waiter.h"

waiter *waiter::m_wa = NULL;

waiter::waiter()
{

}

waiter::~waiter()
{

}

waiter *waiter::instance()
{
    if(!m_wa) {
        m_wa = new waiter();
    }

    return m_wa;
}

void waiter::distance()
{
    if(m_wa) {
        delete m_wa;
        m_wa = NULL;
    }
}
void waiter::bookfood(const char *food)
{
    std::cout << "好嘞！！一份" << std::string(food) << "!!!" << std::endl;
}
