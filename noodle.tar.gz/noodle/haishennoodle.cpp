#include <iostream>
#include "haishennoodle.h"

haishennoodle::haishennoodle()
{

}

haishennoodle::~haishennoodle()
{

}

void haishennoodle::eating()
{
    std::cout << "我是海参炒面，里面没有海参哦！！吃的时候注意!" << std::endl;
}
