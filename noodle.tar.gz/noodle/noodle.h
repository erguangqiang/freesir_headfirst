#ifndef NOODLE_H
#define NOODLE_H

class noodle {
public:
    noodle() {}
    ~noodle() {}

public:
    virtual void eating() = 0;
};

#endif // NOODLE_H
