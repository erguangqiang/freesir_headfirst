#include <iostream>
#include "waiter.h"
#include "haishennoodle.h"
#include "lagennoodle.h"

waiter::waiter()
{

}

waiter::~waiter()
{

}

noodle *waiter::createnoodle(int type)
{
    noodle *n = NULL;
    switch(type) {
    case 0:
        n = new haishennoodle();
        break;
    case 1:
        n = new lagennoodle();
        break;
     default:
        std::cout << "对不起，我们这没有这个菜，请您换一个！" << std::endl;
    }

    return n;
}
