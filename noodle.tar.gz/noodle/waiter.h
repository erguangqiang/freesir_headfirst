#ifndef WAITER_H
#define WAITER_H

class noodle;
class waiter
{
public:
    waiter();
    ~waiter();

public:
    noodle *createnoodle(int type);
};

#endif // WAITER_H
