#include <iostream>
#include <string.h>
#include "haishennoodle.h"
#include "lagennoodle.h"
#include "waiter.h"

using namespace std;

char *product_list[] = {
    "haishen-noodle",
    "lagen-noodle",
    NULL
};

int main()
{
    char *p = NULL;
    char *pd = "haishen-noodle";
    int i = 0;

    waiter *w = new waiter();
    noodle *n = NULL;

    for(p = product_list[i]; p != NULL; i++, p = product_list[i]) {
        if(strncmp(pd, p, strlen(pd)) == 0) {
            n = w->createnoodle(i);
            if(n) {
                cout << "开吃！！！" << endl;
                n->eating();
            }
        }
    }

    if(n) {
        delete n; n = NULL;
    }

    if(w) {
        delete w; w = NULL;
    }

    return 0;
}
