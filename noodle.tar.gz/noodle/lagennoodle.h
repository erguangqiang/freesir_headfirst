#ifndef LAGENNOODLE_H
#define LAGENNOODLE_H

#include "noodle.h"

class lagennoodle : public noodle
{
public:
    lagennoodle();
    ~lagennoodle();

public:
    virtual void eating();
};

#endif // LAGENNOODLE_H
