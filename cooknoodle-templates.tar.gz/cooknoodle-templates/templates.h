#ifndef TEMPLATES_H
#define TEMPLATES_H


class templates
{
public:
    templates();
    virtual ~templates();

public:
    virtual void cooknoodle();

protected:
    virtual void trimvagetable();
    virtual void washvagetable();
    virtual void makenoodle() = 0;
};

#endif // TEMPLATES_H
