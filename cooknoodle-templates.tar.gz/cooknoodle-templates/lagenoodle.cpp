#include <iostream>
#include "lagenoodle.h"

lagenoodle::lagenoodle()
{

}

lagenoodle::~lagenoodle()
{

}

void lagenoodle::makenoodle()
{
    std::cout << "制作辣根汤面正在进行过..." << std::endl;
}
