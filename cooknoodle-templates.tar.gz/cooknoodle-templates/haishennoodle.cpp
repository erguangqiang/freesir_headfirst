#include <iostream>
#include "haishennoodle.h"

haishennoodle::haishennoodle()
{

}

haishennoodle::~haishennoodle()
{

}

void haishennoodle::makenoodle()
{
    std::cout << "制作海参炒面正在进行..." << std::endl;
}
