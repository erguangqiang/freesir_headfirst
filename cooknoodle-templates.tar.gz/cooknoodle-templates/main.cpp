#include <iostream>

#include "haishennoodle.h"
#include "lagenoodle.h"

using namespace std;

int main()
{
    templates *t = new haishennoodle();
    t->cooknoodle();

    delete t; t = NULL;

    t = new lagenoodle();
    t->cooknoodle();

    delete t; t = NULL;
    return 0;
}
