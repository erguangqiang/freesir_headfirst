#ifndef LAGENOODLE_H
#define LAGENOODLE_H

#include "templates.h"

class lagenoodle : public templates
{
public:
    lagenoodle();
    virtual ~lagenoodle();

private:
    virtual void makenoodle();
};

#endif // LAGENOODLE_H
