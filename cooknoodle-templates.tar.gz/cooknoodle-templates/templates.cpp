#include <iostream>
#include "templates.h"

templates::templates()
{

}

templates::~templates()
{

}

void templates::cooknoodle()
{
    trimvagetable();
    washvagetable();

    makenoodle();
}

void templates::trimvagetable()
{
    std::cout << "择菜环节正在进行..." << std::endl;
}

void templates::washvagetable()
{
    std::cout << "洗菜环节正在进行..." << std::endl;
}
