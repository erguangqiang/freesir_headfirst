#ifndef HAISHENNOODLE_H
#define HAISHENNOODLE_H

#include "templates.h"

class haishennoodle : public templates
{
public:
    haishennoodle();
    virtual ~haishennoodle();

private:
    virtual void makenoodle();
};

#endif // HAISHENNOODLE_H
