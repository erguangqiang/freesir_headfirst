#include <iostream>
#include "haishen.h"
#include "haishennoodle.h"

haishen::haishen()
{

}

haishen::~haishen()
{

}

noodle *haishen::createnoodle()
{
    std::cout << "面是我炒得，我的名字叫海参！！！" << std::endl;
    return new haishennoodle();
}
