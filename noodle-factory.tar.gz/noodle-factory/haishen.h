#ifndef HAISHEN_H
#define HAISHEN_H

#include "waiter.h"

class noodle;
class haishen : public waiter
{
public:
    haishen();
    ~haishen();

    virtual noodle *createnoodle();
};

#endif // HAISHEN_H
