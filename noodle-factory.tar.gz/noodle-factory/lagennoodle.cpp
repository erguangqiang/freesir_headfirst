#include <iostream>
#include "lagennoodle.h"

lagennoodle::lagennoodle()
{

}

lagennoodle::~lagennoodle()
{

}

void lagennoodle::eating()
{
    std::cout << "我是辣根汤面，吃完呛的哼啊！！！" << std::endl;
}
