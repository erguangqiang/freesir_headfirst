#ifndef WAITER_H
#define WAITER_H

class noodle;
class waiter
{
public:
    waiter() {}
    ~waiter() {}

    virtual noodle *createnoodle() = 0;
};

#endif // WAITER_H
