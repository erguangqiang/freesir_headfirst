#include <iostream>
#include <string.h>

#include "haishen.h"
#include "lagen.h"
#include "noodle.h"

using namespace std;

char *product_list[] = {
    "haishen-noodle",
    "lagen-noodle",
    NULL
};

int main()
{
    char *p = NULL;
    char *pd = "haishen-noodle";
    int i = 0;

    waiter *w = NULL;
    noodle *n = NULL;

    for(p = product_list[i]; p != NULL; i++, p = product_list[i]) {
        if(strncmp(pd, p, strlen(pd)) == 0) {
           if(i == 0) {
               w = new haishen();
           } else if(i == 1) {
               w = new lagen();
           } else {
               cout << "对不起，请您排在队内！！！" << std::endl;
               break;
           }

        }
    }

    if(w) n = w->createnoodle();
    if(n) n->eating();

    if(w) {
        delete w; w = NULL;
    }

    if(n) {
        delete n; n = NULL;
    }
    return 0;
}
