#ifndef HAISHENNOODLE_H
#define HAISHENNOODLE_H

#include "noodle.h"

class haishennoodle : public noodle
{
public:
    haishennoodle();
    ~haishennoodle();

    virtual void eating();
};

#endif // HAISHENNOODLE_H
