#ifndef LAGENNOODLE_H
#define LAGENNOODLE_H

#include "noodle.h"

class lagennoodle : public noodle
{
public:
    lagennoodle();
    ~lagennoodle();

    virtual void eating();
};

#endif // LAGENNOODLE_H
