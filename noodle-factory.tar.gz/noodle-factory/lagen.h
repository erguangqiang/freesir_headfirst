#ifndef LAGEN_H
#define LAGEN_H

#include "waiter.h"

class lagen : public waiter
{
public:
    lagen();
    ~lagen();

    virtual noodle *createnoodle();
};

#endif // LAGEN_H
