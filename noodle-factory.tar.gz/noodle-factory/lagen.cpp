#include <iostream>
#include "lagen.h"
#include "lagennoodle.h"

lagen::lagen()
{

}

lagen::~lagen()
{

}

noodle *lagen::createnoodle()
{
    std::cout << "吃辣根汤面，你不觉得呛得哼吗？?" << std::endl;
    return new lagennoodle();
}
