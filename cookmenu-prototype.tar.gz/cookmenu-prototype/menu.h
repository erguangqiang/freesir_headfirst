#ifndef MENU_H
#define MENU_H

#include <string>
#include "noodle.h"

class menu
{
public:
    menu();
    menu(menu &m);
    ~menu();

    menu *clone();

    int set_noodle(std::string  &n, int m);
public:
    noodle  *m_noo;
};

#endif // MENU_H
