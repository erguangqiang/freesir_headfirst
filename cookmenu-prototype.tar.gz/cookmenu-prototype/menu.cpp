#include "menu.h"

menu::menu()
{

}

menu::menu(menu &m)
{
    //浅拷贝
    //m.m_noo = m_noo;

    //深拷贝
    m_noo = m.m_noo->clone();
}

menu::~menu()
{

}

menu *menu::clone()
{
    return new menu(*this);
}

int menu::set_noodle(std::string  &n, int m)
{
    if(m_noo) {
        delete m_noo;
        m_noo = NULL;
    }

    m_noo = new noodle(n, m);
}
