#include <iostream>
#include "noodle.h"

noodle::noodle(std::string n, int m) : m_name(n), m_money(m)
{

}

noodle::noodle(noodle &n)
{
    m_name = n.m_name;
    m_money = n.m_money;
}

noodle::~noodle()
{

}

noodle *noodle::clone()
{
    return new noodle(*this);
}
