#include <iostream>
#include "menu.h"

using namespace std;

int main()
{
    string name = "";
    menu *m1 = new menu();
    name = "海参炒面";
    m1->set_noodle(name, 18);
    menu *m2 = m1->clone();
    cout << m2->m_noo->m_name << m2->m_noo->m_money << endl;

    name = "辣根汤面";
    m2->set_noodle(name, 12);
    cout << m2->m_noo->m_name << m2->m_noo->m_money << endl;

    return 0;
}
