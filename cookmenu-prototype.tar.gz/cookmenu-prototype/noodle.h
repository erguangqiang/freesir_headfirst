#ifndef NOODLE_H
#define NOODLE_H

#include <string>

class noodle
{
public:
    noodle(std::string n, int m);
    noodle(noodle &n);
    ~noodle();

    noodle *clone();

public:
    std::string  m_name;
    int m_money;
};

#endif // NOODLE_H
